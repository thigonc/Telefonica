package classes;

import classes.Conta;
import classes.Telefone;

public class Cliente {

    private String nome_cliente;
    private Telefone telefone;
    private Conta conta;

    // Constructor
    public Cliente(String nome_cliente, Telefone telefone, Conta conta) {
        this.nome_cliente = nome_cliente;
        this.telefone = telefone;
        this.conta = conta;
    }

    public void realizarRecarga(){

        // Valida que o cliente tem saldo suficiente para a recarga
        if(this.conta.getSaldo() < this.conta.getRecarga()){
            System.out.println("Cliente nao possui saldo suficiente para realizar a recarga");
            return;
        }

        // Diminui o valor da Recarga do saldo da Conta
        this.conta.setSaldo(this.conta.getSaldo() - this.conta.getRecarga());

        // Acrescenta o saldo no Telefone
        this.telefone.setSaldo(this.telefone.getSaldo() + this.conta.getRecarga());

    }

    @Override
    public String toString() {
        return "Cliente:\n" +
                "   Nome do Cliente = '" + nome_cliente + '\'' + "\n" +
                "Telefone: \n" +
                "   Numero = " + this.telefone.getNumeroLinha() + "\n" +
                "   Saldo = " + this.telefone.getSaldo() + "\n" +
                "Conta: \n" +
                "   Saldo = " + this.conta.getSaldo() + "\n" +
                "   Valor da Recarga = " + this.conta.getRecarga()
                ;
    }

    // Getters e Setters
    public void setNome(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    public String getNome() {
        return this.nome_cliente;
    }

    public void setLinha(Telefone telefone) {
        this.telefone = telefone;
    }

    public Telefone getTelefone() {
        return this.telefone;
    }

    public void setConta(Conta conta) {
        this.conta = conta;
    }

    public Conta getConta() {
        return this.conta;
    }

}
