package classes;

public class Conta {

    private int saldo;
    private int vl_recarga;

    // Construtor
    public Conta(int saldo, int vl_recarga) {
        this.saldo = saldo;
        this.vl_recarga = vl_recarga;
    }

    @Override
    public String toString() {
        return "Conta{" +
                "saldo=" + saldo +
                ", vl_recarga=" + vl_recarga +
                '}';
    }

    // Getters e Setters
    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public int getSaldo() {
        return this.saldo;
    }

    public void setRecarga(int vl_recarga) {
        this.vl_recarga = vl_recarga;
    }

    public int getRecarga() {
        return this.vl_recarga;
    }

}
