package classes;

public class Telefone {

    private String numero_linha;
    private int saldo;

    // Construtor
    public Telefone(String numero_linha, int saldo) {
        this.numero_linha = numero_linha;
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "Telefone{" +
                "numero_linha='" + numero_linha + '\'' +
                ", saldo=" + saldo +
                '}';
    }

    // Getters e Setters
    public void setNumeroLinha(String numero_linha) {
        this.numero_linha = numero_linha;
    }

    public String getNumeroLinha() {
        return this.numero_linha;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public int getSaldo() {
        return this.saldo;
    }
}
