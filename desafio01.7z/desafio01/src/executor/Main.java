package executor;

import classes.Cliente;
import classes.Conta;
import classes.Telefone;

public class Main {

    public static void main(String[] args) {

        // Telefone do cliente
        Telefone tel = new Telefone("998712312", 10);

        // Conta do cliente
        Conta con = new Conta(500, 100);

        // Cliente
        Cliente cli = new Cliente("Gilvani", tel, con);

        // Realizar a recarga
        cli.realizarRecarga();

    }
}
