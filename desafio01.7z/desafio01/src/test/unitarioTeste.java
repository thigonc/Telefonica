package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import org.junit.Test;
import classes.Cliente;
import classes.Conta;
import classes.Telefone;

public class unitarioTeste {

    @Test
    public void test01()  {
        Telefone telefone0 = new Telefone("", 0);
        Conta conta0 = new Conta(0, 529);
        Cliente cliente0 = new Cliente("ClienteName", telefone0, conta0);
        conta0.setSaldo(529);
        conta0.setRecarga(1);
        cliente0.realizarRecarga();
        assertEquals(1, telefone0.getSaldo());
        assertEquals("Conta{saldo=528, vl_recarga=1}", conta0.toString());
    }

    @Test
    public void test04() {
        Telefone telefone0 = new Telefone("9182738172", (-3376));
        Conta conta0 = new Conta((-3376), (-3376));
        Cliente cliente0 = new Cliente((String) null, telefone0, conta0);
        conta0.setRecarga(0);
        cliente0.realizarRecarga();
        assertNull(cliente0.getNome());
    }

    @Test
    public void test05()  {
        Telefone telefone0 = new Telefone("", 0);
        Conta conta0 = new Conta(0, 529);
        Cliente cliente0 = new Cliente("ClienteName", telefone0, conta0);
        conta0.setSaldo(529);
        cliente0.realizarRecarga();
        assertEquals(0, conta0.getSaldo());
        assertEquals(529, telefone0.getSaldo());
    }

}
